# emotion-based-music-ai

just clone this repo or download

and run app.py 
